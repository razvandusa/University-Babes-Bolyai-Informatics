package curs3.io;

import curs3.io.domain.Utilizator;
import curs3.io.domain.validators.UtilizatorValidator;
import curs3.io.domain.validators.ValidationException;
import curs3.io.repository.InMemoryRepository;
import curs3.io.repository.Repository;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Repository<Long, Utilizator> repo = new InMemoryRepository<>(
               new UtilizatorValidator()
        );
        Utilizator utilizator1 = new Utilizator("Andrei1", "Chirila");
        Utilizator utilizator2 = new Utilizator("Andrei2", "Chirila");
        Utilizator utilizator3 = new Utilizator("Andrei3", "Chirila");

        utilizator1.setId(1L);
        utilizator2.setId(2L);
        utilizator3.setId(3L);

        try {
            repo.save(utilizator1);
            repo.save(utilizator2);
            repo.save(utilizator3);

            Utilizator utilizator4 = new Utilizator("Andrei4", "Chirila");
            utilizator4.setId(2L);
            repo.save(utilizator4);

            repo.delete(3L);
            Utilizator u = repo.delete(5L);

            System.out.println("Nu a fost sters nici un user");
            System.out.println(u.getFirstName());
        }
        catch(ValidationException e) {
            System.out.println(e.getMessage());
        }
        catch (IllegalArgumentException e1) {
            System.out.println(e1.getMessage());
        }
        catch (NullPointerException e2) {
            System.out.println("Nu exista user cu acest id");
        }

        try{
            Utilizator new_utilizator = new Utilizator("Matei", "Chirila");
            new_utilizator.setId(10L);
            //utilizator2.setFirstName("Mihai");
            //System.out.println(repo.findOne(utilizator2.getId()).getFirstName());
            repo.update(new_utilizator);
        }
        catch(IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
        catch(ValidationException e){
            System.out.println(e.getMessage());
        }
        repo.findAll().forEach(System.out::println);
        repo.findAll().forEach((Utilizator x) -> System.out.println(x));
//        try {
//            repo.save(null);
//        }
//        catch(IllegalArgumentException e) {
//            System.out.println("exceptie!");
//        }
   }
}
