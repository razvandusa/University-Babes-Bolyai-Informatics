package scs.map.sem9_paging.controller;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import scs.map.sem9_paging.domain.Movie;

import scs.map.sem9_paging.observer.Observer;
import scs.map.sem9_paging.service.MovieService;
import scs.map.sem9_paging.util.event.EntityChangeEvent;
import scs.map.sem9_paging.util.event.EntityChangeEventType;
import scs.map.sem9_paging.util.paging.Page;
import scs.map.sem9_paging.util.paging.Pageable;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MovieController implements Observer<EntityChangeEvent> {
    private MovieService movieService;
    private ObservableList<Movie> model = FXCollections.observableArrayList();
    @FXML
    private TableView<Movie> tableView;
    @FXML
    private TableColumn<Movie, Long> tableColumnId;
    @FXML
    private TableColumn<Movie, String> tableColumnTitle;
    @FXML
    private TableColumn<Movie, String> tableColumnDirector;
    @FXML
    private TableColumn<Movie, Integer> tableColumnYear;
    @FXML
    private Button buttonNext;
    @FXML
    private Button buttonPrevious;
    @FXML
    private Label labelPage;
    @FXML
    private ComboBox<Integer> comboBoxfilterYear;
    @FXML
    private TextField textFieldfilterYearAfter;
    @FXML
    private TextField textFieldfilterDirector;
    @FXML
    private TextField textFieldfilterTitle;
    
    private int pageSize = 5;
    private int currentPage = 0;
    private int totalNumberOfElements = 0;



    public void setMovieService(MovieService movieService) {
        //TODO
    }

    private void initYearsCombo() {
        //TODO
    }

    @FXML
    public void initialize() {
        //TODO

    }



    private void initModel() {
        //TODO
    }

    public void onDelete(ActionEvent actionEvent) {
        Movie selected = tableView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Optional<Movie> deleted = movieService.delete(selected.getId());
            if (deleted.isPresent()) {
                //MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Delete", "Movie has been deleted");
                // initModel();
            }
        } else {
            MessageAlert.showErrorMessage(null, "Select a movie first!");
        }
    }

    @Override
    public void update(EntityChangeEvent event) {
        if (event.getType() == EntityChangeEventType.DELETE) {
            currentPage = 0;
            initModel();
        }

    }

    public void onNextPage(ActionEvent actionEvent) {
        currentPage ++;
        initModel();
    }

    public void onPreviousPage(ActionEvent actionEvent) {
        currentPage --;
        initModel();
    }
}


