
public class Angajat implements HasID<String> {
    private String angajatId;
    private String nume;
    private float venitPeOra;
    private Nivel nivel;

    public Angajat(String angajatId, String nume, float venitPeOra, Nivel nivel) {
        this.angajatId = angajatId;
        this.nume = nume;
        this.venitPeOra = venitPeOra;
        this.nivel = nivel;
    }

    @Override
    public String getId() {
        return angajatId;
    }

    public String getNume() {
        return nume;
    }

    public float getVenitPeOra() {
        return venitPeOra;
    }

    public Nivel getNivel() {
        return nivel;
    }

    @Override
    public String toString() {
        return nume + " | " + nivel + " | " + venitPeOra;
    }
}
