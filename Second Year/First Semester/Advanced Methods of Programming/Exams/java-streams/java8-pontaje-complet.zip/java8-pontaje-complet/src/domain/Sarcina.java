
public class Sarcina implements HasID<String> {
    private String sarcinaId;
    private Dificultate dificultate;
    private int nrOreEstimate;

    public Sarcina(String sarcinaId, Dificultate dificultate, int nrOreEstimate) {
        this.sarcinaId = sarcinaId;
        this.dificultate = dificultate;
        this.nrOreEstimate = nrOreEstimate;
    }

    @Override
    public String getId() {
        return sarcinaId;
    }

    public Dificultate getDificultate() {
        return dificultate;
    }

    public int getNrOreEstimate() {
        return nrOreEstimate;
    }
}
