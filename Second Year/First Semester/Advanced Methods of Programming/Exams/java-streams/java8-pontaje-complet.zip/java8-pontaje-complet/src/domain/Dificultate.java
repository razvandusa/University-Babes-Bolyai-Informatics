
public enum Dificultate {
    Usoara, Medie, Grea
}
