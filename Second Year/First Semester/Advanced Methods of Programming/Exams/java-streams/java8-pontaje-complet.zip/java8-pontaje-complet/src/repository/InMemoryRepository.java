
import java.util.*;

public class InMemoryRepository<ID, T extends HasID<ID>> implements Repository<ID, T> {

    protected Map<ID, T> entities = new HashMap<>();

    public void add(T entity) {
        entities.put(entity.getId(), entity);
    }

    @Override
    public Collection<T> findAll() {
        return entities.values();
    }
}
