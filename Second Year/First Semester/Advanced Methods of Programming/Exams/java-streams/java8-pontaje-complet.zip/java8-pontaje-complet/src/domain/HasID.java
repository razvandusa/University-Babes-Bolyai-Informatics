
public interface HasID<ID> {
    ID getId();
}
