
public enum Nivel {
    Junior, Medium, Senior
}
