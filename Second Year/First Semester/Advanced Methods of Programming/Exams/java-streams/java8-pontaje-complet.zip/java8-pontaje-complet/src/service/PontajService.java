
import java.util.*;
import java.util.stream.Collectors;

public class PontajService {

    private Repository<String, Angajat> angajatRepo;
    private Repository<String, Sarcina> sarcinaRepo;
    private Repository<String, Pontaj> pontajRepo;

    public PontajService(Repository<String, Angajat> angajatRepo,
                         Repository<String, Sarcina> sarcinaRepo,
                         Repository<String, Pontaj> pontajRepo) {
        this.angajatRepo = angajatRepo;
        this.sarcinaRepo = sarcinaRepo;
        this.pontajRepo = pontajRepo;
    }

    public Map<Nivel, List<Angajat>> getAngajatiGrupati() {
        return angajatRepo.findAll().stream()
                .sorted(Comparator
                        .comparing(Angajat::getNivel)
                        .thenComparing(Angajat::getVenitPeOra, Comparator.reverseOrder()))
                .collect(Collectors.groupingBy(
                        Angajat::getNivel,
                        LinkedHashMap::new,
                        Collectors.toList()));
    }

    public Map<Dificultate, Double> getDurataMedieSarcini() {
        return sarcinaRepo.findAll().stream()
                .collect(Collectors.groupingBy(
                        Sarcina::getDificultate,
                        Collectors.averagingInt(Sarcina::getNrOreEstimate)));
    }

    public List<Angajat> getTop2Harnici() {
        Map<Angajat, Integer> oreLucrate =
                pontajRepo.findAll().stream()
                        .collect(Collectors.groupingBy(
                                Pontaj::getAngajat,
                                Collectors.summingInt(p -> p.getSarcina().getNrOreEstimate())));

        return oreLucrate.entrySet().stream()
                .sorted((e1, e2) -> Double.compare(
                        e2.getKey().getVenitPeOra() * e2.getValue(),
                        e1.getKey().getVenitPeOra() * e1.getValue()))
                .limit(2)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

//    public Map<Nivel, List<String>> getRaportSalariiPeLuna(int luna)
//    {
//        Map<Angajat, Double> salarii =
//                pontajRepo.findAll().stream()
//                        .filter(p -> p.getData().getMonthValue() == luna)
//                        .collect(Collectors.groupingBy(
//                                Pontaj::getAngajat,
//                                Collectors.summingDouble(p -> p.getAngajat().getVenitPeOra() * p.getSarcina().getNrOreEstimate())
//                        ));
//
//        return salarii.entrySet().stream()
//                .collect(Collectors.groupingBy(
//                        e -> e.getKey().getNivel(),
//                        Collectors.mapping(
//                                e -> String.format(Locale.US, "%s: %.2f", e.getKey().getNume(), e.getValue()),
//                                Collectors.toList()
//                        )
//                ));
//    }

//    public Map<Nivel, List<String>> getRaportSalariiPeLuna(int luna) {
//
//        // 1. Ore lucrate pe angajat în luna dată
//        Map<Angajat, Integer> orePeLuna =
//                pontajRepo.findAll().stream()
//                        .filter(p -> p.getData().getMonthValue() == luna)
//                        .collect(Collectors.groupingBy(
//                                Pontaj::getAngajat,
//                                Collectors.summingInt(p ->
//                                        p.getSarcina().getNrOreEstimate())
//                        ));
//
//        // 2. Grupare după nivel + calcul salariu
//        return orePeLuna.entrySet().stream()
//                .map(e -> {
//                    Angajat a = e.getKey();
//                    double salariu = a.getVenitPeOra() * e.getValue();
//                    return new AbstractMap.SimpleEntry<>(
//                            a.getNivel(),
//                            a.getNume() + " | " + a.getNivel() + " | " + salariu
//                    );
//                })
//                // 3. sortare crescătoare după salariu
//                .sorted(Comparator.comparingDouble(e ->
//                        Double.parseDouble(e.getValue().split("\\|")[2].trim())
//                ))
//                // 4. grupare finală: Junior → Medium → Senior
//                .collect(Collectors.groupingBy(
//                        Map.Entry::getKey,
//                        LinkedHashMap::new,
//                        Collectors.mapping(
//                                Map.Entry::getValue,
//                                Collectors.toList()
//                        )
//                ));
//    }

    public Map<Nivel, List<String>> getRaportSalariiPeLuna(int luna) {

        // 1. ore lucrate pe angajat = suma orelor estimate ale sarcinilor
        Map<Angajat, Integer> orePeLuna =
                pontajRepo.findAll().stream()
                        .filter(p -> p.getData().getMonthValue() == luna)
                        .collect(Collectors.groupingBy(
                                Pontaj::getAngajat,
                                Collectors.summingInt(p ->
                                        p.getSarcina().getNrOreEstimate())
                        ));

        // 2. calcul salariu + sortare + grupare
        return orePeLuna.entrySet().stream()
                .map(e -> {
                    Angajat a = e.getKey();
                    double salariu = e.getValue() * a.getVenitPeOra();
                    return new AbstractMap.SimpleEntry<>(
                            a.getNivel(),
                            a.getNume() + " " + salariu + " " + a.getNivel()
                    );
                })
                // sortare CRESCĂTOARE după salariu (numeric!)
                .sorted(Comparator.comparingDouble(e ->
                        Double.parseDouble(e.getValue().split(" ")[1])
                ))
                // grupare finală pe nivel (Junior → Medium → Senior)
                .collect(Collectors.groupingBy(
                        Map.Entry::getKey,
                        LinkedHashMap::new,
                        Collectors.mapping(
                                Map.Entry::getValue,
                                Collectors.toList()
                        )
                ));
    }



}
