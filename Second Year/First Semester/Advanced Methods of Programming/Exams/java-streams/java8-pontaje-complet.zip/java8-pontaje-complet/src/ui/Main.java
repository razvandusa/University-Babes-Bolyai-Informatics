
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Main {
    public static void main(String[] args) throws Exception {

        InMemoryRepository<String, Angajat> angajatRepo = new InMemoryRepository<>();
        InMemoryRepository<String, Sarcina> sarcinaRepo = new InMemoryRepository<>();
        InMemoryRepository<String, Pontaj> pontajRepo = new InMemoryRepository<>();

        Files.lines(Paths.get("data/angajati.txt"))
                .map(l -> l.split(","))
                .map(a -> new Angajat(a[0], a[1], Float.parseFloat(a[2]), Nivel.valueOf(a[3])))
                .forEach(angajatRepo::add);

        Files.lines(Paths.get("data/sarcini.txt"))
                .map(l -> l.split(","))
                .map(s -> new Sarcina(s[0], Dificultate.valueOf(s[1]), Integer.parseInt(s[2])))
                .forEach(sarcinaRepo::add);

        DateTimeFormatter df = DateTimeFormatter.ofPattern("d/M/yyyy");

        Files.lines(Paths.get("data/pontaje.txt"))
                .map(l -> l.split(","))
                .forEach(p -> pontajRepo.add(
                        new Pontaj(
                                angajatRepo.entities.get(p[0]),
                                sarcinaRepo.entities.get(p[1]),
                                LocalDate.parse(p[2], df)
                        )
                ));

        PontajService service = new PontajService(angajatRepo, sarcinaRepo, pontajRepo);

        System.out.println("CERINTA 1:");
        service.getAngajatiGrupati().forEach((k, v) -> {
            System.out.println(k);
            v.forEach(System.out::println);
        });

        System.out.println("\nCERINTA 2:");
        service.getDurataMedieSarcini().forEach(
                (k, v) -> System.out.println(k + " -> " + v));

        System.out.println("\nCERINTA 3:");
        service.getTop2Harnici().forEach(
                a -> System.out.println(a.getNume()));

        System.out.println("\nCERINTA 4 – Raport salarii luna 3:");
        service.getRaportSalariiPeLuna(3).forEach((nivel, lista) -> {
            System.out.println(nivel);
            lista.forEach(System.out::println);
        });

    }
}
