
import java.time.LocalDate;

public class Pontaj implements HasID<String> {
    private Angajat angajat;
    private Sarcina sarcina;
    private LocalDate data;

    public Pontaj(Angajat angajat, Sarcina sarcina, LocalDate data) {
        this.angajat = angajat;
        this.sarcina = sarcina;
        this.data = data;
    }

    public Angajat getAngajat() {
        return angajat;
    }

    public Sarcina getSarcina() {
        return sarcina;
    }

    public LocalDate getData() {
        return data;
    }

    @Override
    public String getId() {
        return "";
    }
}
